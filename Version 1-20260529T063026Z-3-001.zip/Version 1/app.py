from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Menu with specific variants and image placeholders
MENU = {
    "Drinks": [
        {"id": 1, "name": "Espresso", "price": 100, "img": "espresso.jpg"},
        {"id": 2, "name": "Americano", "price": 120, "img": "americano.jpg"},
        {"id": 3, "name": "Latte", "price": 150, "img": "latte.jpg"},
        {"id": 4, "name": "Caramel Macchiato", "price": 165, "img": "caramel.jpg"},
        {"id": 5, "name": "Matcha Latte", "price": 160, "img": "matcha.jpg"},
    ],
    "Pastries": [
        {"id": 6, "name": "Classic Croissant", "price": 95, "img": "croissant.jpg"},
        {"id": 7, "name": "Ube Cheese Pandesal", "price": 45, "img": "ube.jpg"},
    ],
    "Rice Meals": [
        {"id": 8, "name": "Tapsilog", "price": 185, "img": "tapsilog.jpg"},
        {"id": 9, "name": "Longsilog", "price": 165, "img": "longsilog.jpg"},
    ]
}


@app.route('/')
def index():
    return render_template('index.html', categories=MENU)


@app.route('/voice-command', methods=['POST'])
def voice_command():
    data = request.json
    text = data.get('text', '').lower()

    # Simple logic to find items in speech
    found_item = None
    for category in MENU.values():
        for item in category:
            if item['name'].lower() in text:
                found_item = item
                break

    if found_item:
        return jsonify({
            "success": True,
            "item": found_item,
            "reply": f"Adding a {found_item['name']} to your cart. Anything else?"
        })

    return jsonify({
        "success": False,
        "reply": "I'm sorry, I couldn't find that item. Would you like a Latte or maybe some Tapsilog?"
    })


if __name__ == '__main__':
    app.run(debug=True)